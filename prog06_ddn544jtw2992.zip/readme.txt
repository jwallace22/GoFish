This is the readme file for the GoFish! programming assignmnent.
Written by Jeffrey Wallace (jtw2992) and Darren Nguyen (ddn544).

Once the file is unizpped:
1. type make into the command terminal
2. open gofish_results.txt
3. you should now be viewing a transcript of the GoFish game between our players Brad and Chad. 

Assumptions made about gameplay:
- if a player runs out of cards in their hand after booking or giving a card to the other player, they draw a card unless the deck is empty.
- if the deck is empty, the players keep playing until both of their hands are empty as well.
- the books are stored as both individual cards in an array of that players books instead of being coupled together.
- we edited some of the optional functions given in the source code so that it fit our game flow better. Mainly by changing param's. 
